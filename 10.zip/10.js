var nums = [];
